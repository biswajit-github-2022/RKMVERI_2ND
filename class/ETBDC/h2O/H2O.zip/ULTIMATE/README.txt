Prerequisites:
install java version 8-17.


Do this process in Sysadm.
--------------------------------------------------------------------------
https://h2o-release.s3.amazonaws.com/h2o/rel-3.46.0/1/index.html
-Download URL for H2O.
-Do it in both the computers which need to be connected.
-Make a folder first.
-Download the h2o.zip then unzip it and change its name to "h2o" and put it in that new folder.
--------------------------------------------------------------------------
https://docs.h2o.ai/h2o/latest-stable/h2o-docs/downloading.html
-go to this URL for installing H2O as python package.
-navigate to "Install in Python" an dexecute following commands.

--------------------------------------------------------------------------
-Create a file inside new folder named "flatfile.txt"
-Now check which device's first 3 components of ipv4 are same
-Only those Devices will be connected in one cluster.
-Example Structure of flatfile:(IP:PORT)
172.20.241.39:54321
172.20.241.21:54321

172.20.241. need to be same for both devices.

-PORT has to be same .
-(Important) the SAME flatfile has to be in each node.
-If Another node wants to join the cluster then that node's IP:PORT has to be added in flatfile of every Node.

* Multinode connection Documentation: https://h2o-release.s3.amazonaws.com/h2o/rel-noether/4/docs-website/deployment/multinode.html

command***: 
java -Xmx20g -jar h2o.jar -flatfile flatfile.txt -port 54321
PORT has to be the one given in flatfile

<path_to_h2o.jar>:
go inside renamed h2o folder , open terminal in that folder, type command "pwd" to get the path.

then run the command*** in nodes one by one.

this will be shown after 2nd node is connected:
INFO WATER: Cloud of size 2 formed [/...]...


now open file_transfer.ipynb